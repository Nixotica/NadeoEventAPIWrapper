class Club:
    def __init__(
        self,
        club_id: int,
    ):
        self._club_id = club_id

    # TODO init other variables by calling the API GET https://live-services.trackmania.nadeo.live/api/token/club/9
